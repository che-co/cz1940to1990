This R script can be use to attribute citiest to 1990 CZ identifiers.
